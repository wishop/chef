## v1.4.0:

* [COOK-2479] - Permit users cookbook to work with chef-solo if
  edelight/chef-solo-search is installed
* [COOK-2486] - specify precedence when setting node attribute

## v1.3.0:

* [COOK-1842] - allow specifying private SSH keys
* [COOK-2021] - Empty default recipe for including users LWRPs

## v1.2.0:

* [COOK-1398] - Provider manage.rb ignores username attribute
* [COOK-1582] - ssh_keys should take an array in addition to a string
  separated by new lines

## v1.1.4:

* [COOK-1396] - removed users get recreated
* [COOK-1433] - resolve foodcritic warnings
* [COOK-1583] - set passwords for users

## v1.1.2:

* [COOK-1076] - authorized_keys template not found in another cookbook

## v1.1.0:

* [COOK-623] - LWRP conversion
