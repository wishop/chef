

default['jboss']['jboss_home'] = "/usr/local/jboss/default"
default['jboss']['version'] = "7.0.2"
default['jboss']['dl_url'] = "http://download.jboss.org/jbossas/7.0/jboss-as-7.0.2.Final/jboss-as-7.0.2.Final.tar.gz"
default['jboss']['jboss_user'] = "jboss"
